Postmortem Companion for Windows

The companion is optional. You can use the Postmortem website on its own.
https://deadlock-compare.minnymods.workers.dev/profile.html

This pilot works with the two Steam accounts Zachary approved.

1. Right-click the ZIP and choose Extract All. Keep postmortem-companion.exe
   and pm-reader.exe in the same folder. The companion starts the reader.
2. Open the extracted folder, type powershell in File Explorer's address
   bar, and press Enter. The first time, run this command.
   .\postmortem-companion.exe --init-config
   If you already have settings, the app keeps them.
3. When Zachary asks you to test, run this before you queue in Deadlock.
   .\postmortem-companion.exe --watch
   The companion finds your Steam library and saves a local capture after
   you return to Hideout. New settings keep uploads off.
4. Press Ctrl+C in the PowerShell window to stop. Run this to see the result.
   .\postmortem-companion.exe --report

If Windows or your antivirus blocks the app, stop and tell Zachary exactly
what it says.
