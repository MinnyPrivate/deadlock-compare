# MVP / Key Player tag art (Deadlock pak01, extracted 2026-11-13, read-only)

Source: game/citadel/pak01_dir.vpk. Tag panels live in
panorama/layout/post_game/citadel_db_post_game_scoreboard_new.xml (scoreboard rows) and
citadel_db_post_game_team.xml (team portrait cards). Player panel gets class MVP_Rank1 (MVP) or MVP_Rank2/MVP_Rank3 (Key Player).
match_details_graphs has no MVP/Key references.

## Localization (citadel_main_english.txt)
Citadel_Post_Game_MVP = "MVP"
Citadel_Post_Game_MVP_HonorableMention = "Key Player"
Citadel_Post_Game_MVP_KeyPlayers = "Key Players"

## Scoreboard row (citadel_db_post_game_scoreboard_new.vcss), in .PlayerInfoContainer .RightSide (flow-children: right)
.MVPContainer { vertical-align: center; width: 36px; height: 48px; img-shadow: 0px 0px 4px #00000088; }
.MVPContainer .MVP { background-image: url("s2r://panorama/images/post_game/mvp_trophy.vsvg"); background-size: contain; background-position: center; background-repeat: no-repeat; width: 100%; height: 100%; visibility: collapse; }
.Player.MVP_Rank1 .MVPContainer .MVP { visibility: visible; }
.MVPContainer .MVP_HonorableMention { background-image: url("s2r://panorama/images/post_game/key_player_trophy.vsvg"); (same sizing); visibility: collapse; }
.Player.MVP_Rank2 / .MVP_Rank3 .MVPContainer .MVP_HonorableMention { visibility: visible; }
Tooltips: #Citadel_Post_Game_MVP / #Citadel_Post_Game_MVP_HonorableMention.

## Team portrait card (citadel_db_post_game_team.vcss)
.MVPContainer { horizontal-align: center; vertical-align: top; animation-name: AwardReveal; animation-duration: .24s; animation-timing-function: ease-in-out; margin-left: -20px; margin-top: 48px; }
  (.Left3/.Right3 margin-top 0px; .Left2/.Right2 margin-top 16px)
.MVPContainer .MVP, .MVPContainer .MVP_HonorableMention { font-size: 24px; font-family: oracle; color: goldenLightShine; text-shadow: 0px 0px 0px 12 black; padding: 12px 0 0 0; letter-spacing: 2px; vertical-align: center; text-overflow: shrink; font-weight: bold; }
.MVPContainer .MVP { visibility: collapse; text-transform: uppercase; margin-top: 0px; font-size: 64px; pre-transform-rotate2d: -3deg; padding-left: 80px; animation-duration: 1.5s; }
.MVPContainer .MVP_HonorableMention { visibility: collapse; animation-duration: 1.7s; pre-transform-rotate2d: -2deg; padding-left: 68px; color: #927446; }
.MVPContainer .MVPTrophy { background-image: mvp_trophy.vsvg; background-size: contain; no-repeat; background-position: left center; margin-bottom: -8px; width: 120px; height: 160px; img-shadow: 0px 0px 4px #00000088; horizontal-align: left; vertical-align: center; ui-scale: 70%; }
.MVPContainer .KeyPlayerTrophy { background-image: key_player_trophy.vsvg; background-size: contain; no-repeat; background-position: center; width: 120px; height: 160px; img-shadow: 0px 0px 4px #00000088; horizontal-align: left; vertical-align: center; ui-scale: 70%; }
.Player.MVP_Rank1 .PlayerBorder { wash-color: goldenLight; opacity-mask: url(hero_logo_mask_psd.vtex); opacity-mask-scale: 100% 100%; brightness: 2.3; }
.Player.MVP_Rank2/3 .PlayerBorder { same, brightness: 0.5; }
.Player.MVP_Rank1/2/3 .PlayerCard { pre-transform-scale2d: 1.015; }
.Player.MVP_RankN.CommendedPlayer .PlayerBorder { wash-color: #314945; opacity-mask: url(hero_logo_mask_psd.vtex) 0; brightness: 1; }

Defines (citadel_base_styles.vcss):
@define goldenLight: #c6a269;
@define goldenLightShine: gradient( radial, 50% 50%, -5% -5%, 60% 60%, from( #FFE2AA), to( #BE9D6B ) );
@keyframes 'AwardReveal' (citadel_db_post_game_award.vcss) { 0% { opacity: 0; pre-transform-scale2d: 0.2; pre-transform-rotate2d: -10deg; } 80% { pre-transform-scale2d: 1.1; pre-transform-rotate2d: 2deg; } 100% { opacity: 1; pre-transform-scale2d: 1; pre-transform-rotate2d: -2.2deg; } }

## Files
images/post_game/*.svg = decoded vsvg_c; *.png = decoded vtex_c (mvp_bg_png was an embedded PNG; DXT5/BGRA ones decoded with a stdlib decoder); raw *_c alongside.
Used by the tags: mvp_trophy, key_player_trophy, hero_logo_mask_psd. Others (key_player_bg_*, mvp_bg_*, mvp_fade, mvp_scene, starburst_*, nav_icon_mvp) belong to the MVP screen / nav, included for reference.
notes/ = full decompiled scoreboard/team CSS and layout ASTs (a few garbage bytes at the start of each CSS).
