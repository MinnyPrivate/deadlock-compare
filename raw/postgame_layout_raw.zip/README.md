# Post-game page layout (Deadlock pak01, decoded 2026-11-13, read-only)
Plain-text decodes of the real Valve files (layouts rebuilt from the compiled AST, CSS from the DATA block; a few stray bytes may lead each CSS file).
Images: bg_team1/2_psd, bg_team_mask_psd, postgame_bg_psd raw + PNG (DXT5 decoded with a stdlib decoder; colours may be off if Valve used YCoCg).

Key findings
(a) Screen art: #Team1Screen/#Team2Screen are the .PostGameScreen panels themselves and carry
  #Team1Screen{background-image: bg_team1_psd.vtex; background-size: cover; background-position: center}
  #Team1Screen{background-color: gradient(radial, 50% 0%, 0% 0%, 40% 40%, from(team1Color&10), to(team1ColorDarker&08))}
  (same for Team2). The 3D hero renders live inside CitadelPostGameTeam: CitadelScenePanel #HeroScenePanelBacker
  (map ui/hero_select_backer/post_game_backer, opacity .08/.1, full size) and per-player CitadelHeroScenePanelNew #HeroScenePanel (height 800px).
(b) Page background: CitadelPostGameNew{background-color: offBlack} with @define offBlack: #10130D. .Body{width/height 100%} no background.
  .DashboardPage only animates opacity/scale/wash-color.
(c) .FooterBar is the last child of .AsyncSuccessContainer, after #ScreensCarousel: {vertical-align: bottom; width: 100%; opacity 0 -> 1 with ProgressState_None/Completed}. No z-index, no background. The dashboard's own #FooterBar (z-index 100) is hidden on this page via dashboardclass NoFooterBar.
